using System;
using System.Collections.Generic;
namespace SOLID_19005324
{
    public class students

    {
        public static string studentReport(List<Student> students){
            int fullTime = 0;
            int distance = 0;
            string ftStudents = String.Empty;
            string dtStudents = String.Empty;
            
            foreach (Student item in students)
            {
                if (item is FullTimeStudent)
                {
                    FullTimeStudent fts = (FullTimeStudent)item;
                    fullTime++;
                    ftStudents += $"{fts.getId()}\t{fts.getFirstName()}\t{fts.getLectureHours()}\t{fts.getCampus()}\n";
                }
                
                else if (item is DistanceStudent)
                {
                    DistanceStudent dts = (DistanceStudent)item;
                    distance++;
                    dtStudents += $"{dts.getId()}\t{dts.getFirstName()}\t{dts.getLectureHours()}\t{dts.getFacilitator()}\n";
                    
                }
            }

            return $"There are {fullTime} Full Time Students\nThere are {distance} Part Time Students\n\nFULL TIME STUDENTS:\n{ftStudents}\n\nPART TIME STUDENTS:\n{dtStudents}";
        }
        }
    }
}